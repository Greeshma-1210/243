import React from 'react';
const StudentInfo=(props)=>{
    return(
        <div>
            <table>
                <tbody>
                    <tr>
                    <td>RollNo</td>
                    <td>:</td>
                    <td>{props.RollNo}</td>
                    </tr>
                    <tr>
                    <td>Name:</td>
                    <td>:</td>
                    <td>{props.Name}</td>
                    </tr>
                    <tr>
                    <td>PhnNo</td>
                    <td>:</td>
                    <td>{props.PhnNo}</td>
                    </tr>
                </tbody>
            </table>
        </div>
          );
};
        export default StudentInfo;