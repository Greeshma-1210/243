import WelcomeMessage from"./components/welcome";
import Studentinfo from"./components/Studentinfo";
function App() {
  return (
    <div className="App">
      <div className="container-fluid">
        <WelcomeMessage/>
        <Studentinfo RollNo="2211cs010243" Name="Greeshma" PhnNo="8121737003"/>

      </div>
      
    </div>
  );
}

export default App;
